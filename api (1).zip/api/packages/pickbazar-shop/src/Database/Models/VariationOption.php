<?php

namespace PickBazar\Database\Models;

use Illuminate\Database\Eloquent\Model;

class VariationOption extends Model
{
    protected $table = 'variation_options';

    public $guarded = [];
}
